﻿param($roleName, $instanceName,[Switch]$Debug)

function Log($logfile, $message) {
    $null = "$([DateTime]::Now) $message" | Out-File -Append $logfile    
}

function Trace($logfile, $text) {
    if (-not $text) { return }
    $text = $text.Trim()
    if (-not $text) { return }
    if ($text -eq ".") { return }
    if ($text -eq "..") { return }
    if ($text -eq "...") { return }

    Write-Host $text
    Log $logfile $text
}

# Execute the role deployment commands
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$deployment = [Xml](Get-Content "$scriptRoot\Deployment.xml")
$logfile = "$scriptRoot\Deploy.log"
$CmdExe = "$($env:SystemDrive)\Windows\System32\cmd.exe"

$role = $deployment.HostingDeployment.TemplateReference.HostingTemplate.Roles.Role | where {$_.Name -ieq $roleName}

$role.VMOnStartActions.ExecuteAction | where {$_} | foreach {
    $e = $_
    $cmd = $e.InnerText

    if ($cmd -eq $null) { $cmd = $e }
    
    if ($cmd -ne $null) {
        Log $logfile "Executing: $($cmd.Trim())"

        $success = $false
        $retry = $e.Retry
        if (([int]$retry) -eq 0) { $retry = 3 }
        $runMode = "/c"
        if ($Debug) { $runMode = "/k" }

        do {
            Write-Host $retry":" $cmd

            $startinfo = New-Object System.Diagnostics.ProcessStartInfo
            $startinfo.FileName = $CmdExe
            $startinfo.WorkingDirectory = "$scriptRoot\$($e.RunInFolder)"
            $startinfo.Arguments = @($runMode,$cmd) -join " "
            $startinfo.RedirectStandardOutput = $true
            $startinfo.RedirectStandardError = $true
            $startinfo.UseShellExecute = $false

            $proc = New-Object System.Diagnostics.Process
            $proc.StartInfo = $startinfo

            $null = $proc.Start()

            while (-not $proc.HasExited) {
                Trace $logfile ($proc.StandardOutput.ReadLine())
            }

            if (-not $proc.StandardOutput.EndOfStream) {
                Trace $logfile ($proc.StandardOutput.ReadToEnd())
            }

            if (-not $proc.StandardError.EndOfStream) {
                Trace $logfile "Error"
                Trace $logfile ($proc.StandardError.ReadToEnd())
            }

            if ($proc.ExitCode -ne $e.ExpectedExitCodeField) {
                $retry --
                $success = $false
                Write-Host -ForegroundColor Red Error code $($proc.ExitCode)
                Log $logfile "Exception $($proc.Exitcode)"
                Start-Sleep -Seconds 5
            } else {
                $success = $true
                Write-Host -ForegroundColor Green Success
                Log $logfile "Success"
            }
        } while (($retry -gt 0) -and (-not $success))

        if (-not $success) { 
            Write-Host -ForegroundColor Red "Can't complete $($cmd.Trim())" 
            Log $logfile "Can't complete $($cmd.Trim())"
        }
    } else {
        Write-Host "Unable to find execution command"
        Log $logfile "Error in $($e.OutterXml)"
    }
}

if (-not $Debug) {
    # Remove Autologon

    Start-Process -Wait $CmdExe -ArgumentList '/c','reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v AutoAdminLogon /d 0 /t REG_SZ /f'
    Start-Process -Wait $CmdExe -ArgumentList '/c','reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultUsername /d 0 /t REG_SZ /f'
    Start-Process -Wait $CmdExe -ArgumentList '/c','reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultPassword /d 0 /t REG_SZ /f'

    # Logoff the admin
    logoff
}