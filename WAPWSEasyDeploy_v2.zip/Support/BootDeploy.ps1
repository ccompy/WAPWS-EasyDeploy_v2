﻿param($roleName, $instanceName)

# Execute the role deployment commands
$deployment = [Xml](Get-Content C:\Deployment\Deployment.xml)

$role = $deployment.HostingDeployment.TemplateReference.HostingTemplate.Roles.Role | where {$_.Name -ieq $roleName}

$role.VMOnStartActions.ExecuteAction | foreach {
    $e = $_
    $cmd = $e.InnerText

    if ($cmd -eq $null) { $cmd = $e }
    
    if ($cmd -ne $null) {
        Write-Host Executing: $cmd.Trim()

        $success = $false
        $retry = $e.Retry
        if ($retry -eq 0) { $retry = 3 }

        do {
            $proc = Start-Process -Wait -PassThru -WorkingDirectory ("C:\Deployment\"+$e.RunInFolder) C:\Windows\System32\cmd.exe -ArgumentList '/c',$cmd
            if ($proc.ExitCode -ne $e.ExpectedExitCodeField) {
                $retry --
                $success = $false
                Write-Host -ForegroundColor Red Error code $($proc.ExitCode)
            } else {
                $success = $true
            }
        } while (($retry -gt 0) -and (-not $success))

        if (-not $success) { Write-Error "Can't complete $($cmd.Trim())" }
    } else {
        Write-Host "Unable to find execution command"
    }
}

# Remove Autologon

Start-Process -Wait C:\Windows\System32\cmd.exe -ArgumentList '/c','reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v AutoAdminLogon /d 0 /t REG_SZ /f'
Start-Process -Wait C:\Windows\System32\cmd.exe -ArgumentList '/c','reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultUsername /d 0 /t REG_SZ /f'
Start-Process -Wait C:\Windows\System32\cmd.exe -ArgumentList '/c','reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultPassword /d 0 /t REG_SZ /f'

# Logoff the admin
logoff