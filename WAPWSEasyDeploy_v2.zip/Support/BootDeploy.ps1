﻿param($roleName, $instanceName,[Switch]$Debug)

function Log($logfile, $message) {
    $null = "$([DateTime]::Now) $message" | Out-File -Append $logfile    
}

# Execute the role deployment commands
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$deployment = [Xml](Get-Content "$scriptRoot\Deployment.xml")
$logfile = "$scriptRoot\Deploy.log"
$CmdExe = "$($env:SystemDrive)\Windows\System32\cmd.exe"

$role = $deployment.HostingDeployment.TemplateReference.HostingTemplate.Roles.Role | where {$_.Name -ieq $roleName}

$role.VMOnStartActions.ExecuteAction | where {$_} | foreach {
    $e = $_
    $cmd = $e.InnerText

    if ($cmd -eq $null) { $cmd = $e }
    
    if ($cmd -ne $null) {
        Log $logfile "Executing: $($cmd.Trim())"

        $success = $false
        $retry = $e.Retry
        if (([int]$retry) -eq 0) { $retry = 3 }
        $runMode = "/c"
        if ($Debug) { $runMode = "/k" }

        do {
            Write-Host $retry":" $cmd

            $proc = Start-Process -Wait -PassThru -WorkingDirectory ("$scriptRoot\$($e.RunInFolder)") $CmdExe -ArgumentList $runMode,$cmd
            if ($proc.ExitCode -ne $e.ExpectedExitCodeField) {
                $retry --
                $success = $false
                Write-Host -ForegroundColor Red Error code $($proc.ExitCode)
                Log $logfile "Exception $($proc.Exitcode)"
                Start-Sleep -Seconds 5
            } else {
                $success = $true
                Write-Host -ForegroundColor Green Success
                Log $logfile "Success"
            }
        } while (($retry -gt 0) -and (-not $success))

        if (-not $success) { 
            Write-Host -ForegroundColor Red "Can't complete $($cmd.Trim())" 
            Log $logfile "Can't complete $($cmd.Trim())"
        }
    } else {
        Write-Host "Unable to find execution command"
        Log $logfile "Error in $($e.OutterXml)"
    }
}

if (-not $Debug) {
    # Remove Autologon

    Start-Process -Wait $CmdExe -ArgumentList '/c','reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v AutoAdminLogon /d 0 /t REG_SZ /f'
    Start-Process -Wait $CmdExe -ArgumentList '/c','reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultUsername /d 0 /t REG_SZ /f'
    Start-Process -Wait $CmdExe -ArgumentList '/c','reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultPassword /d 0 /t REG_SZ /f'

    # Logoff the admin
    logoff
}