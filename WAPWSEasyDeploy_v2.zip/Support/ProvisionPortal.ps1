param(
    [string] $adminPassword,
    [string] $sqlservername, 
    [string] $sqlsysadmin, 
    [string] $sqlsysadminpwd,
    [string] $configStorePassphrase,
    [string] $feed,
    [string] $serviceEndPoint,
    [string] $serviceUserName,
    [string] $servicePassword,
    [string] $mysqlservername,
    [string] $mysqlsysadmin,
    [string] $mysqlsysadminpwd
)

Write-Host "Disabling IE enhanced security"
$AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}" 
Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0  
# $UserKey = "HKCU:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}" 
# Set-ItemProperty -Path $UserKey -Name "IsInstalled" -Value 0  
Stop-Process -Name Explorer  

Write-Host "Enable WMI-in firewall rule"
$Rules = (New-Object -COM HNetCfg.FwPolicy2).rules
foreach ($Rule in $Rules) {
    if ($Rule.Name -like "*WMI*" -and $Rule.Direction -like "*1*" ) {
        $Rule.Enabled = "True"
    }
}

Write-Host "Enable PSRemoting"
Enable-PSRemoting -Force
Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any

Write-Host "Get Web Platform Installer"
$wpiCmd = "C:\Program Files\Microsoft\Web Platform Installer\WebpiCmd.exe"

if (-not (Test-Path $wpiCmd)) {
    $client = New-Object System.Net.WebClient
    $client.DownloadFile('http://go.microsoft.com/fwlink/?LinkId=287166', ($pwd.Path+'\WebPlatformInstaller.msi'))

    Write-Host 'Install Web Platform Installer'
    msiexec.exe /i ($pwd.Path+'\WebPlatformInstaller.msi') /qn /Lv* Install-WebPI.log
}

while (-not (Test-Path $wpiCmd)) { Start-Sleep 1 }

Write-Host "Install Portal"
if ([String]::IsNullOrEmpty($feed)) {
    & $wpiCmd /Install /Products:"WAP_AdminApiAndServiceProviders_Bundle,WAP_AdminSite_Bundle,WAP_AuthSite_Bundle,WAP_SingleMachineInstallation,WAP_TenantApi_Bundle,WAP_TenantPublicApi_Bundle,WAP_TenantSite_Bundle,WAP_WindowsAuthSite_Bundle" /AcceptEula /SuppressPostFinish
} else {
    Write-Host "Check Feed"
    $client = New-Object System.Net.WebClient
    $null = $client.DownloadString($feed)
    
    & $wpiCmd /Install /XML:$feed /Products:"WAP_AdminApiAndServiceProviders_Bundle,WAP_AdminSite_Bundle,WAP_AuthSite_Bundle,WAP_SingleMachineInstallation,WAP_TenantApi_Bundle,WAP_TenantPublicApi_Bundle,WAP_TenantSite_Bundle,WAP_WindowsAuthSite_Bundle" /AcceptEula /SuppressPostFinish
}

Write-Host "Wait for Database"
$dbconnect = New-Object System.Data.SqlClient.SqlConnection
$dbconnect.ConnectionString = "server=$($sqlservername);database=master;uid=$($sqlsysadmin);pwd=$($sqlsysadminpwd);"

while ($dbconnect.State -ne "Open") {
    try {
        $dbconnect.Open()
    } catch {
        Start-Sleep -Seconds 1
    }
}

$dbconnect.Close()

Write-Host "Configure Portal Preview"
Import-Module -Name MgmtSvcConfig

$settings = @{`
    dbServer = $sqlservername;`
    dbAdminUserName = $sqlsysadmin;`
    dbAdminPassword = $sqlsysadminpwd;`
    configStorePassphrase = $configStorePassphrase`
}

Initialize-MgmtSvcFeature -Name AdminAPI -Settings $settings -Verbose
Initialize-MgmtSvcFeature -Name AdminSite -Settings $settings -Verbose
Initialize-MgmtSvcFeature -Name AuthSite -Settings $settings -Verbose
Initialize-MgmtSvcFeature -Name Monitoring -Settings $settings -Verbose
Initialize-MgmtSvcFeature -Name MySQL -Settings $settings -Verbose
Initialize-MgmtSvcFeature -Name SQLServer -Settings $settings -Verbose
Initialize-MgmtSvcFeature -Name TenantAPI -Settings $settings -Verbose
Initialize-MgmtSvcFeature -Name TenantPublicAPI -Settings $settings -Verbose
Initialize-MgmtSvcFeature -Name TenantSite -Settings $settings -Verbose
Initialize-MgmtSvcFeature -Name UsageCollector -Settings $settings -Verbose
Initialize-MgmtSvcFeature -Name UsageService -Settings $settings -Verbose
Initialize-MgmtSvcFeature -Name WebAppGallery -Settings $settings -Verbose
Initialize-MgmtSvcFeature -Name WindowsAuthSite -Settings $settings -Verbose

# Get admin token
Import-Module -Name MgmtSvcAdmin

$password = ConvertTo-SecureString $adminPassword -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential (whoami),$password

$adminUrl = "https://localhost:30004"
$token = Get-MgmtSvcToken -Type Windows -AuthenticationSite "https://localhost:30072" -ClientRealm "http://azureservices/AdminSite" -User $credential -DisableCertificateValidation

# Also add the SQL database to portal
Import-Module -Name MgmtSvcSqlServer

$group = Get-MgmtSvcSqlServerGroup -AdminUri $adminUrl -Token $token -DisableCertificateValidation -GroupName Default

$server = New-Object Microsoft.WindowsAzure.Server.Sql.Client.SqlHostingServer
$server.Name = $sqlservername
$server.TotalSpaceMB = 10240
$server.ConnectionString = "server=$sqlservername;uid=$sqlsysadmin;password=$sqlsysadminpwd;"

$null = Add-MgmtSvcSqlHostingServer -ServerGroupId $group.GroupId -HostingServer $server -AdminUri $adminUrl -Token $token -DisableCertificateValidation

# Add MySQL database to portal
if ($mysqlservername) {
    Import-Module -Name MgmtSvcMySql

    $group = Get-MgmtSvcMySqlServerGroup -AdminUri $adminUrl -Token $token -DisableCertificateValidation -GroupName Default

    $server = New-Object Microsoft.WindowsAzure.Server.MySql.Client.MySqlHostingServer
    $server.Name = $mysqlservername
    $server.TotalSpaceMB = 10240
    $server.ConnectionString = "server=$mysqlservername;uid=$mysqlsysadmin;password=$mysqlsysadminpwd;"

    $null = Add-MgmtSvcMySqlHostingServer -ServerGroupId $group.GroupId -HostingServer $server -AdminUri $adminUrl -Token $token -DisableCertificateValidation
}

# Add websites endpoint
if ($serviceEndPoint) {
    Write-Host "Wait for websites management portal"
    $client = New-Object System.Net.WebClient
    $client.Credentials = New-Object System.Net.NetworkCredential -ArgumentList $serviceUserName,$servicePassword

    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { return $true }

    do {
        try {
            $null = $client.DownloadString($serviceEndPoint)
            break
        } catch {
            Start-Sleep 5
        }
    } while ($true)

    Write-Host "Add websites endpoint"
    
    $rp = New-MgmtSvcResourceProviderConfiguration -Name 'webspaces' `
        -DisplayName 'Web Site Cloud' `
        -AllowMultipleInstances '1' `
        -AdminForwardingAddress $serviceEndPoint `
        -AdminAuthenticationMode 'Basic' `
        -TenantForwardingAddress $serviceEndPoint `
        -TenantAuthenticationMode 'Basic' `
        -TenantSourceUriTemplate '{subid}/services/webspaces/{*path}' `
        -TenantTargetUriTemplate 'subscriptions/{subid}/webspaces/{*path}' `
        -NotificationForwardingAddress "$serviceEndPoint/quotamanagement" `
        -NotificationAuthenticationMode 'Basic' `
        -AdminAuthenticationUserName $serviceUserName `
        -AdminAuthenticationPassword $servicePassword `
        -TenantAuthenticationUserName $serviceUserName `
        -TenantAuthenticationPassword $servicePassword `
        -NotificationAuthenticationUserName $serviceUserName `
        -NotificationAuthenticationPassword $servicePassword `
        -UsageForwardingAddress $serviceEndPoint `
        -UsageAuthenticationMode 'Basic' `
        -UsageAuthenticationUserName $serviceUserName `
        -UsageAuthenticationPassword $servicePassword

    $storeConnection = "Data Source=$sqlservername;Initial Catalog=Microsoft.MgmtSvc.Store;User ID=$sqlsysadmin;Password=$sqlsysadminpwd;Asynchronous Processing=True;Application Name=Management"
    $configConnection = "Data Source=$sqlservername;Initial Catalog=Microsoft.MgmtSvc.Config;User ID=$sqlsysadmin;Password=$sqlsysadminpwd;Asynchronous Processing=True;Application Name=Management"
    $setting = Get-MgmtSvcDatabaseSetting -Namespace AdminAPI -Name machineKey.decryptionKey -ConnectionString $configConnection -Passphrase $configStorePassphrase

    Add-MgmtSvcResourceProviderConfiguration -ConnectionString $storeConnection -EncryptionKey $setting.Value -EncryptionAlgorithm "AES" -ResourceProvider $rp -Force -Verbose

    # Get publisher and its ip
    $xml = [Xml]($client.DownloadString("$serviceEndPoint/webadmin/systems"))

    $domains = @($xml.WebSystems.WebSystem.FtpDns,$xml.WebSystems.WebSystem.PublishingDns)

    $websystem = $xml.WebSystems.WebSystem.Name

    $xml = [Xml]($client.DownloadString("$serviceEndPoint/webadmin/systems/$websystem/publishers"))
    $publisher = $xml.Servers.Server.Name
    
    [System.Net.Dns]::GetHostAddresses($publisher) | where {$_.AddressFamily -eq "InterNetwork"} | foreach {
        $publisherip = $_.IPAddressToString
    }

    # Add ip to host file is not resolved correctly
    $domains | foreach {
        $d = $_
        $match = [System.Net.Dns]::GetHostAddresses($d) | where {($_.AddressFamily -eq "InterNetwork") -and ($_.IPAddressToString -eq $publisherip) }

        if (-not $match) {
            "$publisherip $d" | Out-File -Encoding ASCII -Append "$($env:SystemRoot)\System32\Drivers\etc\hosts"
        }
    }
}

# Add a default plan
$plan = New-Object Microsoft.WindowsAzure.Server.Management.Plan

$plan.DisplayName = "WAP Default Plan"

'sqlservers','mysqlservers','webspaces' | foreach {
    $service = Get-MgmtSvcResourceProvider -AdminUri $adminUrl -Token $token -DisableCertificateValidation -Name $_

    if ($service) {
        $quota = New-Object Microsoft.WindowsAzure.Server.Management.ServiceQuota
        $quota.ServiceName = $service.Name
        $quota.ServiceDisplayName = $service.DisplayName
        $quota.ServiceInstanceId = $service.InstanceId

        $plan.ServiceQuotas.Add($quota)
    }    
}

Add-MgmtSvcPlan -Plan $plan -AdminUri $adminUrl -Token $token -DisableCertificateValidation

