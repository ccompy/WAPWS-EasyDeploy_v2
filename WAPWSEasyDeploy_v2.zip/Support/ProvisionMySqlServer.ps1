﻿param(
    [string] $CustomFeed,
    [string] $rootPassword
)

Write-Host "Get Web Platform Installer"
$wpiCmd = "$($env:SystemDrive)\Program Files\Microsoft\Web Platform Installer\WebpiCmd.exe"

if (-not (Test-Path $wpiCmd)) {
    $client = New-Object System.Net.WebClient
    $client.DownloadFile('http://go.microsoft.com/fwlink/?LinkId=287166', ($pwd.Path+'\WebPlatformInstaller.msi'))

    Write-Host 'Install Web Platform Installer'
    msiexec.exe /i ($pwd.Path+'\WebPlatformInstaller.msi') /qn /Lv* Install-WebPI.log
}

while (-not (Test-Path $wpiCmd)) { Start-Sleep 1 }

Write-Host "Install MySQL"
$retry = 3
$installed = $false
do {
    if ($CustomFeed) {
        & $wpiCmd /Install /XML:$CustomFeed /Products:"MySQL" /MySQLPassword:$rootPassword /AcceptEula /SuppressPostFinish /Log:Install-MySQL.log
    } else {
        & $wpiCmd /Install /Products:"MySQL" /MySQLPassword:$rootPassword /AcceptEula /SuppressPostFinish /Log:Install-MySQL.log
    }
    
    if (($LastExitCode) -and ($LastExitCode -ne 0)) {
        $retry --
        if ($retry -le 0) {
            Write-Error "Failed to install product MySQL"
            Exit $LastExitCode
        }
    } else {
        $installed = $true
    }
} while (-not $installed)

Write-Host "Config MySQL"
& 'C:\Program Files\MySQL\MySQL Server 5.1\bin\mysql.exe' -u root -p mysql --password=$rootPassword --execute="GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY '$rootPassword' WITH GRANT OPTION"
& 'C:\Program Files\MySQL\MySQL Server 5.1\bin\mysql.exe' -u root -p mysql --password=$rootPassword --execute="FLUSH PRIVILEGES"
& 'C:\Program Files\MySQL\MySQL Server 5.1\bin\mysql.exe' -u root -p mysql --password=$rootPassword --execute="UPDATE user SET grant_priv='Y' WHERE user='root'"

net stop mysql
net start mysql

Write-Host "Open File Wall"
netsh advfirewall firewall add rule name=MySQL-TCP dir=in localport=3306 protocol=TCp action=allow

