param($controller,$adminuser,$password,$portal,$portaluser,$portalpass)

# Make sure the client can connect to the controller
$trusted = Get-Item WSMan:\localhost\Client\TrustedHosts -ErrorAction SilentlyContinue
if (($trusted -ne $null) -and ([String]::IsNullOrEmpty($trusted.Value))) {
    try {
        Set-Item WSMan:\localhost\Client\TrustedHosts -Value '*' -Force -ErrorAction SilentlyContinue
    } catch {
        throw 'failed to set trust relation, please do it manually'
    }
}

# Step 1 Able to see controller
$spassword = ConvertTo-SecureString $password -AsPlainText -Force
$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $adminuser,$spassword

do {
    try {
        $csession = New-PSSession -ComputerName $controller -Credential $credential -ErrorAction SilentlyContinue
    } catch { }

    if (-not $csession) {
        Write-Host "$([DateTime]::Now.ToString()) - Waiting for controller"
        Start-Sleep -Seconds 1
    }
} while (-not $csession)
# Keep the session
Write-Host -ForegroundColor Green "$([DateTime]::Now.ToString()) - Controller is up"

# Step 2 Controller setup done
do {
    try {
        Invoke-Command -Session $csession -ScriptBlock { Import-Module Websites -ErrorAction SilentlyContinue } -ErrorAction SilentlyContinue
        $command = Invoke-Command -Session $csession -ScriptBlock { Get-Command Get-WebSitesEvent -ErrorAction SilentlyContinue } -ErrorAction SilentlyContinue  
    } catch { }

    if (-not $command) {
        Write-Host "$([DateTime]::Now.ToString()) - Waiting for Azure pack install on controller"
        Start-Sleep -Seconds 5
    }
} while (-not $command)
Write-Host -ForegroundColor Green "$([DateTime]::Now.ToString()) - Controller done with setup"

# Step 3 Management role up
do {
    try {
        $management = Invoke-Command -Session $csession -ScriptBlock { Get-WebSitesServer -ServerType ManagementServer -ErrorAction SilentlyContinue } -ErrorAction SilentlyContinue | where {$_.ReadyForLoadBalancing }
    } catch { }

    if (-not $management) {
        Write-Host "$([DateTime]::Now.ToString()) - Waiting for management role"
        Start-Sleep -Seconds 5
    }
} while (-not $management)
Write-Host -ForegroundColor Green "$([DateTime]::Now.ToString()) - Management is ready"

# Step 4 Report current status
Invoke-Command -Session $csession -ScriptBlock { Get-WebsitesServer } | select Name,Role,ServerState | Format-Table

Write-Host "Portal user name: $portaluser with password: $portalpass"

# Final, Clean up
Remove-PSSession -Session $csession

