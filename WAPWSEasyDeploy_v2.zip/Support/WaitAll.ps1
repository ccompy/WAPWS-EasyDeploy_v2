param($controller,$adminuser,$password,$portal,$portaluser,$portalpass)

$global:controllerServer = $controller
$global:controllerUser = $adminuser
$global:controllerPassword = $password
$global:webSystem = 'MgmtSvcCloud'

# Make sure the client can connect to the controller
$trusted = Get-Item WSMan:\localhost\Client\TrustedHosts -ErrorAction SilentlyContinue
if (($trusted -ne $null) -and ([String]::IsNullOrEmpty($trusted.Value))) {
    try {
        Set-Item WSMan:\localhost\Client\TrustedHosts -Value '*' -Force -ErrorAction SilentlyContinue
    } catch {
        throw 'failed to set trust relation, please do it manually'
    }
}

# Step 1 Able to see controller
$spassword = ConvertTo-SecureString $global:controllerPassword -AsPlainText -Force
$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $global:controllerUser,$spassword

do {
    try {
        $session = New-PSSession -ComputerName $global:controllerServer -Credential $credential -ErrorAction SilentlyContinue
    } catch { }

    if (-not $session) {
        Write-Host "$([DateTime]::Now.ToString()) - Waiting for controller"
        Start-Sleep -Seconds 2
    }
} while (-not $session)

Remove-PSSession -Session $session -Confirm:$false
$session = $null
Write-Host -ForegroundColor Green "$([DateTime]::Now.ToString()) - Controller is up"

# Step 2 Controller setup done
do {
    try {
        $session = New-PSSession -ComputerName $global:controllerServer -Credential $credential -ErrorAction SilentlyContinue
        Invoke-Command -Session $session -ScriptBlock { Add-PSSnapIn WebHostingSnapIn -ErrorAction SilentlyContinue } -ErrorAction SilentlyContinue
        $command = Invoke-Command -Session $session -ScriptBlock { Get-Command Get-WebSitesEvent -ErrorAction SilentlyContinue } -ErrorAction SilentlyContinue  
    } catch { }

    if ($session -ne $null) {
        Remove-PSSession -Session $session -Confirm:$false
        $session = $null
    }

    if (-not $command) {
        Write-Host "$([DateTime]::Now.ToString()) - Waiting for Azure pack install on controller"
        Start-Sleep -Seconds 2
    }
} while (-not $command)

Write-Host -ForegroundColor Green "$([DateTime]::Now.ToString()) - Controller done with setup"

# Step 3 Management role up
do {
    try {
        $session = New-PSSession -ComputerName $global:controllerServer -Credential $credential -ErrorAction SilentlyContinue
        Invoke-Command -Session $session -ScriptBlock { Add-PSSnapIn WebHostingSnapIn -ErrorAction SilentlyContinue } -ErrorAction SilentlyContinue
        $management = Invoke-Command -Session $session -ScriptBlock { Get-WebSitesServer -ServerType ManagementServer -ErrorAction SilentlyContinue } -ErrorAction SilentlyContinue | where {$_.ReadyForLoadBalancing }
    } catch { }

    if ($session -ne $null) {
        Remove-PSSession -Session $session -Confirm:$false
        $session = $null
    }

    if (-not $management) {
        Write-Host "$([DateTime]::Now.ToString()) - Waiting for management role"
        Start-Sleep -Seconds 2
    }
} while (-not $management)

Write-Host -ForegroundColor Green "$([DateTime]::Now.ToString()) - Management is ready"
