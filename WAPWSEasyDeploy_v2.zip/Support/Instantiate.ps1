﻿param($domain,$user,$password)

#Create user if local
if ([String]::IsNullOrEmpty($domain) -or ($domain -eq '.')) {
    net user $user $password /add /logonpasswordchg:no /expires:never
}

#Add to administrator group
$administratorsSID = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-544")
$administratorsGroupName = $administratorsSID.Translate([System.Security.Principal.NTAccount]).Value

$localizedAdministratorsGroupName=$administratorsGroupName.Split('\')[1]

net localgroup $localizedAdministratorsGroupName $user /add

# Add registration for auto logon
cmd /c reg add 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\Winlogon' /v AutoAdminLogon /t REG_SZ /d 1 /f
cmd /c reg add 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\Winlogon' /v DefaultDomain /t REG_SZ /d $domain /f
cmd /c reg add 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\Winlogon' /v DefaultUserName /t REG_SZ /d $user /f
cmd /c reg add 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\Winlogon' /v DefaultPassword /t REG_SZ /d $password /f
