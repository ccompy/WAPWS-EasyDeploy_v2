param(
    [string] $customFeed,
    [string] $sqlservername, 
    [string] $sqlsysadmin, 
    [string] $sqlsysadminpwd,
    [string] $controllerAdminUserName,
    [string] $controllerAdminPassword,
    [string] $managementServerAdminUserName,
    [string] $managementServerAdminPassword,
    [string] $fileServerAdminUserName,
    [string] $fileServerAdminPassword,
    [string] $frontEndAdminUserName,
    [string] $frontEndAdminPassword,
    [string] $publisherAdminUserName,
    [string] $publisherAdminPassword,
    [string] $workerAdminUserName,
    [string] $workerAdminPassword,
    [string] $dnsSuffix,    
    [string] $fileServerName,
    [string] $fileServerType,
    [string] $fileShareOwnerUserName,
    [string] $fileShareOwnerPassword,
    [string] $fileShareUserUserName,
    [string] $fileShareUserPassword,
    [string] $cloudAdminUserName,
    [string] $cloudAdminPassword,
    [string] $centralCertStoreUserName,
    [string] $centralCertStorePassword,
    [string] $contentShareUNCPath,
    [string] $contentShareLocalPath,
    [string] $certificateShareUNCPath,
    [string] $certificateShareLocalPath,
    [string] $enableSqm,
    [string] $enableMicrosoftUpdate
)

Write-Host "Disabling IE enhanced security"
$AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}" 
Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0  
Stop-Process -Name Explorer  

Write-Host "Enabling remote desktop access"
cscript C:\Windows\System32\scregedit.wsf /ar 0
netsh advfirewall firewall set rule group="@FirewallAPI.dll,-23009" new enable=yes

Write-Host "Open Firewall for File and Printer Sharing"
netsh advfirewall firewall set rule group="@FirewallAPI.dll,-28502" new enable=yes

Write-Host "Open Firewall for Windows Management Instrumentation (WMI)"
netsh advfirewall firewall set rule group="@FirewallAPI.dll,-34251" new enable=yes

Write-Host "Enable PSRemoting"
Enable-PSRemoting -Force
Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any

Write-Host "Get Web Platform Installer"
$wpiCmd = "$($env:SystemDrive)\Program Files\Microsoft\Web Platform Installer\WebpiCmd.exe"

if (-not (Test-Path $wpiCmd)) {
    $client = New-Object System.Net.WebClient
    $client.DownloadFile('http://go.microsoft.com/fwlink/?LinkId=287166', ($pwd.Path+'\WebPlatformInstaller.msi'))

    Write-Host 'Install Web Platform Installer'
    msiexec.exe /i ($pwd.Path+'\WebPlatformInstaller.msi') /qn /Lv* Install-WebPI.log
}

while (-not (Test-Path $wpiCmd)) { Start-Sleep 1 }

Write-Host 'Install Websites'
$retry = 3
$installed = $false
do {
    if ($customFeed) {
        & $wpiCmd /Install /Xml:$customFeed /Products:HostingPrimaryControllerBootstrapper_v2 /AcceptEula /SuppressPostFinish /Log:Install-Controller.log
    } else {
        & $wpiCmd /Install /Products:HostingPrimaryControllerBootstrapper_v2 /AcceptEula /SuppressPostFinish /Log:Install-Controller.log
    }
    
    if (($LastExitCode) -and ($LastExitCode -ne 0)) {
        $retry --
        if ($retry -le 0) {
            Write-Error "Failed to install product MySQL"
            Exit $LastExitCode
        }
    } else {
        $installed = $true
    }
} while (-not $installed)

Write-Host "Wait for Database"
$dbconnect = New-Object System.Data.SqlClient.SqlConnection
$dbconnect.ConnectionString = "server=$($sqlservername);database=master;uid=$($sqlsysadmin);pwd=$($sqlsysadminpwd);"

while ($dbconnect.State -ne "Open") {
    try {
        $dbconnect.Open()
    } catch {
        Start-Sleep -Seconds 1
    }
}

$dbconnect.Close()

Write-Host 'Import Websites module'
Import-Module Websites

Write-Host 'Initialize Websites Instance'
$controllerInitializationSettings = @{`
    hosting = "server=$($sqlservername);database=hosting;uid=$($sqlsysadmin);pwd=$($sqlsysadminpwd);";`
    resourceMetering = "server=$($sqlservername);database=metering;uid=$($sqlsysadmin);pwd=$($sqlsysadminpwd);";`
    managementServerAdminUserName = $managementServerAdminUserName;`
    managementServerAdminPassword = $managementServerAdminPassword;`
    fileServerAdminUserName = $fileServerAdminUserName;`
    fileServerAdminPassword = $fileServerAdminPassword;`
    frontEndAdminUserName = $frontEndAdminUserName;`
    frontEndAdminPassword = $frontEndAdminPassword;`
    publisherAdminUserName = $publisherAdminUserName;`
    publisherAdminPassword = $publisherAdminPassword;`
    workerAdminUserName = $workerAdminUserName;`
    workerAdminPassword = $workerAdminPassword;`
    dnsSuffix = $dnsSuffix;`        
    fileServerName = $fileServerName;`
    fileServerType = $fileServerType;`
    fileShareOwnerUserName = $fileShareOwnerUserName;`
    fileShareOwnerPassword = $fileShareOwnerPassword;`
    fileShareUserUserName = $fileShareUserUserName;`
    fileShareUserPassword = $fileShareUserPassword;`
    cloudAdminUserName = $cloudAdminUserName;`
    cloudAdminPassword = $cloudAdminPassword;`
    centralCertStoreUserName = $centralCertStoreUserName;`
    centralCertStorePassword = $centralCertStorePassword;`
    contentShareUNCPath = $contentShareUNCPath;`
    contentShareLocalPath = $contentShareLocalPath;`
    certificateShareUNCPath = $certificateShareUNCPath;`
    certificateShareLocalPath = $certificateShareLocalPath;`
    enableSqm = $enableSqm;`
    enableMicrosoftUpdate = $enableMicrosoftUpdate;`
    skipManagementServerProvisioning = "True";`
    isVMMBased = "False";`        
}

Initialize-WebSitesInstance -Settings $controllerInitializationSettings -Verbose

Write-Host 'Patch database'
$connection = New-Object System.Data.SqlClient.SqlConnection
$connection.ConnectionString = "server=$sqlservername;database=hosting;user=$sqlsysadmin;password=$sqlsysadminpwd;"
$connection.Open()

$command = $connection.CreateCommand()
$command.CommandText = "ALTER FUNCTION [runtime].[udf_GetStartOfHour]
(@inputDate DATETIME)
RETURNS DATETIME
AS
BEGIN
    -- Use multilanguage compliant ISO 8601 format, example 2004-05-23T14:25:10 or 2004-05-23T14:25:10.487 (http://technet.microsoft.com/en-us/library/ms190977%28v=sql.90%29.aspx)
    RETURN CAST (CAST (YEAR(@inputDate) AS VARCHAR (4)) + '-' + CAST (MONTH(@inputDate) AS VARCHAR (2)) + '-' + CAST (DAY(@inputDate) AS VARCHAR (2)) + 'T' + CAST (DATEPART([hour], @inputDate) AS VARCHAR (2)) + ':00:00' AS DATETIME);

END"
$command.ExecuteNonQuery()

$command = $connection.CreateCommand()
$command.CommandText = "ALTER FUNCTION [runtime].[udf_GetStartOfMinute]
(@inputDate DATETIME)
RETURNS DATETIME
AS
BEGIN
    -- Use multilanguage compliant ISO 8601 format, example 2004-05-23T14:25:10 or 2004-05-23T14:25:10.487 (http://technet.microsoft.com/en-us/library/ms190977%28v=sql.90%29.aspx)
    RETURN CAST (CAST (YEAR(@inputDate) AS VARCHAR (4)) + '-' + CAST (MONTH(@inputDate) AS VARCHAR (2)) + '-' + CAST (DAY(@inputDate) AS VARCHAR (2)) + 'T' + CAST (DATEPART([hour], @inputDate) AS VARCHAR (2)) + ':' + CAST (DATEPART([minute], @inputDate) AS VARCHAR (2)) + ':00' AS DATETIME);
END"
$command.ExecuteNonQuery()

$command = $connection.CreateCommand()
$command.CommandText = "ALTER FUNCTION [runtime].[udf_GetStartOfDay]
(@inputDate DATETIME)
RETURNS DATETIME
AS
BEGIN
    -- Use multilanguage compliant ISO 8601 format, example 2004-05-23T14:25:10 or 2004-05-23T14:25:10.487 (http://technet.microsoft.com/en-us/library/ms190977%28v=sql.90%29.aspx)
    RETURN CAST (CAST (YEAR(@inputDate) AS VARCHAR (4)) + '-' + CAST (MONTH(@inputDate) AS VARCHAR (2)) + '-' + CAST (DAY(@inputDate) AS VARCHAR (2)) + 'T00:00:00' AS DATETIME);
END"
$command.ExecuteNonQuery()

$command = $connection.CreateCommand()
$command.CommandText = "ALTER FUNCTION [runtime].[udf_GetStartOfMonth]
(@inputDate DATETIME)
RETURNS DATETIME
AS
BEGIN
    -- Use multilanguage compliant ISO 8601 format, example 2004-05-23T14:25:10 or 2004-05-23T14:25:10.487 (http://technet.microsoft.com/en-us/library/ms190977%28v=sql.90%29.aspx)
    RETURN CAST (CAST (YEAR(@inputDate) AS VARCHAR (4)) + '-' + CAST (MONTH(@inputDate) AS VARCHAR (2)) + '-01T00:00:00' AS DATETIME);
END"
$command.ExecuteNonQuery()

$connection.Close()
