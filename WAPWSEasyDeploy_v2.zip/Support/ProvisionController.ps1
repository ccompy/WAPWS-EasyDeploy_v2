param(
    [string] $customFeed,
    [string] $sqlservername, 
    [string] $sqlsysadmin, 
    [string] $sqlsysadminpwd,
    [string] $controllerAdminUserName,
    [string] $controllerAdminPassword,
    [string] $managementServerAdminUserName,
    [string] $managementServerAdminPassword,
    [string] $fileServerAdminUserName,
    [string] $fileServerAdminPassword,
    [string] $frontEndAdminUserName,
    [string] $frontEndAdminPassword,
    [string] $publisherAdminUserName,
    [string] $publisherAdminPassword,
    [string] $workerAdminUserName,
    [string] $workerAdminPassword,
    [string] $dnsSuffix,    
    [string] $fileServerName,
    [string] $fileServerType,
    [string] $fileShareOwnerUserName,
    [string] $fileShareOwnerPassword,
    [string] $fileShareUserUserName,
    [string] $fileShareUserPassword,
    [string] $cloudAdminUserName,
    [string] $cloudAdminPassword,
    [string] $centralCertStoreUserName,
    [string] $centralCertStorePassword,
    [string] $contentShareUNCPath,
    [string] $contentShareLocalPath,
    [string] $certificateShareUNCPath,
    [string] $certificateShareLocalPath,
    [string] $enableSqm,
    [string] $enableMicrosoftUpdate
)

Write-Host "Disabling IE enhanced security"
$AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}" 
Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0  
# $UserKey = "HKCU:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}" 
# Set-ItemProperty -Path $UserKey -Name "IsInstalled" -Value 0  
Stop-Process -Name Explorer  

Write-Host "Enable WMI-in firewall rule"
$Rules = (New-Object -COM HNetCfg.FwPolicy2).rules
foreach ($Rule in $Rules) {
    if ($Rule.Name -like "*WMI*" -and $Rule.Direction -like "*1*" ) {
        $Rule.Enabled = "True"
    }
}

Write-Host "Enable PSRemoting"
Enable-PSRemoting -Force
Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any

Write-Host "Get Web Platform Installer"
$wpiCmd = "C:\Program Files\Microsoft\Web Platform Installer\WebpiCmd.exe"

if (-not (Test-Path $wpiCmd)) {
    $client = New-Object System.Net.WebClient
    $client.DownloadFile('http://go.microsoft.com/fwlink/?LinkId=287166', ($pwd.Path+'\WebPlatformInstaller.msi'))

    Write-Host 'Install Web Platform Installer'
    msiexec.exe /i ($pwd.Path+'\WebPlatformInstaller.msi') /qn /Lv* Install-WebPI.log
}

while (-not (Test-Path $wpiCmd)) { Start-Sleep 1 }

Write-Host 'Install Websites'
if ($customFeed) {
    & $wpiCmd /Install /Xml:$customFeed /Products:HostingPrimaryControllerBootstrapper_v2 /AcceptEula /SuppressPostFinish
} else {
    & $wpiCmd /Install /Products:HostingPrimaryControllerBootstrapper_v2 /AcceptEula /SuppressPostFinish
}

Write-Host "Wait for Database"
$dbconnect = New-Object System.Data.SqlClient.SqlConnection
$dbconnect.ConnectionString = "server=$($sqlservername);database=master;uid=$($sqlsysadmin);pwd=$($sqlsysadminpwd);"

while ($dbconnect.State -ne "Open") {
    try {
        $dbconnect.Open()
    } catch {
        Start-Sleep -Seconds 1
    }
}

$dbconnect.Close()

Write-Host 'Add Websites Snapin'
Add-PSSnapin WebHostingSnapin

Write-Host 'Initialize Websites Extension'
$controllerInitializationSettings = @{`
    hosting = "server=$($sqlservername);database=hosting;uid=$($sqlsysadmin);pwd=$($sqlsysadminpwd);";`
    resourceMetering = "server=$($sqlservername);database=metering;uid=$($sqlsysadmin);pwd=$($sqlsysadminpwd);";`
    managementServerAdminUserName = $managementServerAdminUserName;`
    managementServerAdminPassword = $managementServerAdminPassword;`
    fileServerAdminUserName = $fileServerAdminUserName;`
    fileServerAdminPassword = $fileServerAdminPassword;`
    frontEndAdminUserName = $frontEndAdminUserName;`
    frontEndAdminPassword = $frontEndAdminPassword;`
    publisherAdminUserName = $publisherAdminUserName;`
    publisherAdminPassword = $publisherAdminPassword;`
    workerAdminUserName = $workerAdminUserName;`
    workerAdminPassword = $workerAdminPassword;`
    dnsSuffix = $dnsSuffix;`        
    fileServerName = $fileServerName;`
    fileServerType = $fileServerType;`
    fileShareOwnerUserName = $fileShareOwnerUserName;`
    fileShareOwnerPassword = $fileShareOwnerPassword;`
    fileShareUserUserName = $fileShareUserUserName;`
    fileShareUserPassword = $fileShareUserPassword;`
    cloudAdminUserName = $cloudAdminUserName;`
    cloudAdminPassword = $cloudAdminPassword;`
    centralCertStoreUserName = $centralCertStoreUserName;`
    centralCertStorePassword = $centralCertStorePassword;`
    contentShareUNCPath = $contentShareUNCPath;`
    contentShareLocalPath = $contentShareLocalPath;`
    certificateShareUNCPath = $certificateShareUNCPath;`
    certificateShareLocalPath = $certificateShareLocalPath;`
    enableSqm = $enableSqm;`
    enableMicrosoftUpdate = $enableMicrosoftUpdate;`
    skipManagementServerProvisioning = "True";`
    isVMMBased = "False";`        
}

Initialize-WebSitesInstance -Settings $controllerInitializationSettings -Verbose
