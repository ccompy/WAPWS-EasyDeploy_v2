param(
    $dbpassword
)

Write-Host "Get Web Platform Installer"
$wpiCmd = "C:\Program Files\Microsoft\Web Platform Installer\WebpiCmd.exe"

if (-not (Test-Path $wpiCmd)) {
    $client = New-Object System.Net.WebClient
    $client.DownloadFile('http://go.microsoft.com/fwlink/?LinkId=287166', ($pwd.Path+'\WebPlatformInstaller.msi'))

    Write-Host 'Install Web Platform Installer'
    msiexec.exe /i ($pwd.Path+'\WebPlatformInstaller.msi') /qn /Lv* Install-WebPI.log
}

while (-not (Test-Path $wpiCmd)) { Start-Sleep 1 }

Write-Host "Install SQL Server Express"
& $wpiCmd /Install /Products:SQLExpress /SQLPassword:$dbpassword /SuppressPostFinish /AcceptEula

Write-Host "Enable TCP on the server"
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement")
$m = New-Object Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer
$m.ServerInstances[0].ServerProtocols["Tcp"].IsEnabled = $true
$m.ServerInstances[0].ServerProtocols["Tcp"].IPAddresses["IPAll"].IPAddressProperties["TcpDynamicPorts"].Value=[String]::Empty
$m.ServerInstances[0].ServerProtocols["Tcp"].IPAddresses["IPAll"].IPAddressProperties["TcpPort"].Value="1433"
$m.ServerInstances[0].ServerProtocols["Tcp"].Alter()

net stop "SQL Server (SQLEXPRESS)"
net start "SQL Server (SQLEXPRESS)"

Write-Host "Configure the firewall"
netsh advfirewall firewall add rule name="SQL TCP IN" dir=in action=allow protocol=TCP localport=1433


