param(
    [string]$controller,
    [string]$controllerUser,
    [string]$controllerPassword,
    [string]$roleType
)

Write-Host "Disabling IE enhanced security"
$AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}" 
Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0  
# $UserKey = "HKCU:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}" 
# Set-ItemProperty -Path $UserKey -Name "IsInstalled" -Value 0  
Stop-Process -Name Explorer  
Write-Host "Disabled IE enhanced security"

Write-Host "Enabling remote desktop access"
cscript C:\Windows\System32\scregedit.wsf /ar 0

Write-Host "Open Firewall for File and Printer Sharing"
netsh advfirewall firewall set rule group="File and Printer Sharing" new enable=Yes

Write-Host "Open Firewall for Windows Management Instrumentation (WMI)"
netsh advfirewall firewall set rule group="Windows Management Instrumentation (WMI)" new enable=yes

Write-Host "UAC remote settings configuration"
reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\system /v LocalAccountTokenFilterPolicy /t REG_DWORD /d 1 /f

Write-Host "Allow connection to any server"
winrm set winrm/config/client '@{TrustedHosts="*"}'

Write-Host "Schedule .Net Tasks"
schtasks /change /tn "\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319" /enable
schtasks /change /tn "\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319 64" /enable
schtasks /run /tn "\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319"
schtasks /run /tn "\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319 64"

Write-Host "Connect to Controller"
$spassword = ConvertTo-SecureString $controllerPassword -AsPlainText -Force
$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $controllerUser,$spassword
$session = $null
$computer = $env:ComputerName

if (($roleType -eq 'ManagementServer') -or ($roleType -eq 'Publisher') -or ($roleType -eq 'Frontend') -or ($roleType -eq 'Worker')) {
    do {
        if ($session -eq $null) {
            try {
                $session = New-PSSession -ComputerName $controller -Credential $credential -ErrorAction SilentlyContinue
                Invoke-Command -Session $session -ScriptBlock { Add-PSSnapIn WebHostingSnapIn -ErrorAction SilentlyContinue } -ErrorAction SilentlyContinue
                $command = Invoke-Command -Session $session -ScriptBlock { Get-Command Get-WebSitesEvent -ErrorAction SilentlyContinue } -ErrorAction SilentlyContinue
                if ($command -eq $null) { throw 'not ready' }
                    Write-Host Session established
            } catch {
                Write-Host Waiting for session to be established
                if ($session -ne $null) {
                    Remove-PSSession -Session $session -Confirm:$false
                    $session = $null
                }           
            }
        }

        if ($session -ne $null) {
            if ($roleType -eq 'ManagementServer') {
                $result = Invoke-Command -Session $session -ArgumentList @($env:ComputerName) -ScriptBlock {
                    try {
                        New-ManagementServer -ManagementServerName $args[0]
                        $true
                    } catch { $false } }
            }
            if ($roleType -eq 'Publisher') {
                $result = Invoke-Command -Session $session -ArgumentList @($env:ComputerName) -ScriptBlock {
                    try {
                        New-Publisher -PublisherName $args[0]
                        $true
                    } catch { $false } }
            }
            if ($roleType -eq 'FrontEnd') {
                $result = Invoke-Command -Session $session -ArgumentList @($env:ComputerName) -ScriptBlock {
                    try { 
                        New-FrontEnd -FrontEndName $args[0]
                        $true
                    } catch { $false } }
            }
            if ($roleType -eq 'Worker') {
                $result = Invoke-Command -Session $session -ArgumentList @($env:ComputerName) -ScriptBlock { 
                    try {
                        New-Worker -WorkerName $args[0]
                        $true
                    } catch { $false } }
            }

            if ($result) { break }
        }

        sleep -Seconds 5
    } while ($true)

    if ($session -ne $null) {
        Remove-PSSession -Session $session -Confirm:$false
    }
}